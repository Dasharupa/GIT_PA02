﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleSpawner : MonoBehaviour
{
    public GameObject obstacle;
    public GameObject obstacle2;
    public GameObject obstacle3;
    float randX;
    Vector3 whereToSpawn;
    public float spawnRate = 1f;
    float nextSpawn = 1f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Time.time > nextSpawn)
        {
            nextSpawn = Time.time + spawnRate;
            randX = Random.Range(-7.4f, 7.4f);
            whereToSpawn = new Vector3(randX, transform.position.y);
            Instantiate(obstacle, whereToSpawn, Quaternion.identity);
            Instantiate(obstacle2, whereToSpawn, Quaternion.identity);
            Instantiate(obstacle3, whereToSpawn, Quaternion.identity);
        }
    }
}
